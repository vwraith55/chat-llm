

# DocChat

# DocChat is an AI chat agent that can read and analyze files in your current directory using Groq's LLM API.

[![doctest](https://github.com/vwraith55/chat-llm/actions/workflows/doctests.yml/badge.svg)](https://github.com/vwraith55/llm-lab/actions/workflows/doctests.yml)
[![integration-test](https://github.com/vwraith55/chat-llm/actions/workflows/integration-tests.yml/badge.svg)](https://github.com/vwraith55/llm-lab/actions/workflows/integration-tests.yml)

# [![flake8](https://github.com/vwraith55/chat-llm/actions/workflows/flake8.yml/badge.svg)](https://github.com/vwraith55/chat-llm/actions/workflows/flake8.yml)
# [![codecov](https://codecov.io/gh/vwraith55/chat-llm/branch/main/graph/badge.svg)](https://codecov.io/gh/vwraith55/chat-llm)
[![PyPI](https://img.shields.io/pypi/v/cmc-csci040-valerie)](https://pypi.org/project/cmc-csci040-valerie/)
